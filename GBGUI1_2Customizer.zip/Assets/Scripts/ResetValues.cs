using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResetValues : MonoBehaviour
{
    [SerializeField]
    public Slider red;
    [SerializeField]
    public Slider blue;
    [SerializeField]
    public Slider green;

    public void resetValues(){
        blue.value = 1f;
        green.value = 1f;
        red.value = 1f;
    }
}
