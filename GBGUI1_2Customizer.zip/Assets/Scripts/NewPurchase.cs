using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class NewPurchase : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    private CinemachineVirtualCamera OldCamera;
    [SerializeField]
    private CinemachineVirtualCamera newCamera;
    [SerializeField]
    private GameObject overheadPanel;
     [SerializeField]
    private GameObject previousPanel;
    [SerializeField]
    private GameObject previousPanel1;
    [SerializeField]
    private GameObject previousPanel2;
    [SerializeField]
    private GameObject previousPanel3;
    [SerializeField]
    private GameObject confirmPanel;

    
    public void NewPurchases(){
        previousPanel.SetActive(false);
        previousPanel1.SetActive(false);
        previousPanel2.SetActive(false);
        previousPanel3.SetActive(false);
        confirmPanel.SetActive(true);
        StartCoroutine(waitForSec());
        
        
    }

        


    IEnumerator waitForSec()
    {    
        yield return new WaitForSeconds(3);
        Camera.main.gameObject.TryGetComponent<CinemachineBrain>(out var brain);
        if(brain==null) {
            brain = Camera.main.gameObject.AddComponent<CinemachineBrain>();
        }
        brain.m_DefaultBlend.m_Time = 1;
        brain.m_ShowDebugText = true;
        OldCamera.Priority = 10;
        newCamera.Priority = 15;
        confirmPanel.SetActive(false);
        
        overheadPanel.SetActive(true);
    }
}
