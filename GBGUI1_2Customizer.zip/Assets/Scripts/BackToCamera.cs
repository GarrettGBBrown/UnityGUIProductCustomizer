using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
public class BackToCamera : MonoBehaviour
{

    [SerializeField]
    private CinemachineVirtualCamera OldCamera;
    //private Transform focusObjectTransform;
    // Start is called before the first frame update
    [SerializeField]
    private CinemachineVirtualCamera newCamera;
    [SerializeField]
    private CinemachineVirtualCamera OldCamera1;
    [SerializeField]
    private CinemachineVirtualCamera OldCamera2;

    public void MoveCameraBack() {
        Camera.main.gameObject.TryGetComponent<CinemachineBrain>(out var brain);
        if(brain==null) {
            brain = Camera.main.gameObject.AddComponent<CinemachineBrain>();
        }
        brain.m_DefaultBlend.m_Time = 1;
        brain.m_ShowDebugText = true;

        //cinemachineVirtualCamera = gameObject.AddComponent<CinemachineVirtualCamera>();
        ///cinemachineVirtualCamera.Follow = focusObjectTransform;
        //cinemachineVirtualCamera.LookAt = focusObjectTransform;
        OldCamera.Priority = 10;
        OldCamera1.Priority = 10;
        OldCamera2.Priority = 10;
        newCamera.Priority = 15;
    }
}
