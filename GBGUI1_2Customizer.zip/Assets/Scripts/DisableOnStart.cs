using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisableOnStart : MonoBehaviour
{
    // Start is called before the first frame update
     [SerializeField]
    private GameObject previousPanel;
     [SerializeField]
    private GameObject previousPanel4;

    [SerializeField]
    private GameObject previousPanel1;

    [SerializeField]
    private GameObject previousPanel2;
    [SerializeField]
    private GameObject previousPanel3;

    
    
    void Start()
    {
    
        previousPanel.SetActive(false);
        previousPanel1.SetActive(false);
        previousPanel2.SetActive(false);
        previousPanel3.SetActive(false);
        previousPanel4.SetActive(false);


    }

    
}
