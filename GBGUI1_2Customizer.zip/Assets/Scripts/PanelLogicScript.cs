using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelLogicScript : MonoBehaviour
{
     [SerializeField]
    private GameObject previousPanel;
     [SerializeField]
    private GameObject nextPanel;

    [SerializeField]
    private GameObject previousPanel1;

    [SerializeField]
    private GameObject previousPanel2;
    [SerializeField]
    private GameObject previousPanel3;

    
    public void ChangePanels(){
        previousPanel.SetActive(false);
        previousPanel1.SetActive(false);
        previousPanel2.SetActive(false);
        previousPanel3.SetActive(false);
        StartCoroutine(waitForSec());
        
        
    }

        


    IEnumerator waitForSec()
    {    
        yield return new WaitForSeconds(1);
        nextPanel.SetActive(true);
    }
}
