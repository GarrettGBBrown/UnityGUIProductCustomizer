using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

[RequireComponent(typeof(CinemachineVirtualCamera))]
public class CinemachineChanger : MonoBehaviour
{

    [SerializeField]
    private CinemachineVirtualCamera previousVirtualCamera;
    //private Transform focusObjectTransform;
    // Start is called before the first frame update
    [SerializeField]
    private CinemachineVirtualCamera cinemachineVirtualCamera;

    public void MoveToCamera() {
        Camera.main.gameObject.TryGetComponent<CinemachineBrain>(out var brain);
        if(brain==null) {
            brain = Camera.main.gameObject.AddComponent<CinemachineBrain>();
        }
        brain.m_DefaultBlend.m_Time = 1;
        brain.m_ShowDebugText = true;

        //cinemachineVirtualCamera = gameObject.AddComponent<CinemachineVirtualCamera>();
        ///cinemachineVirtualCamera.Follow = focusObjectTransform;
        //cinemachineVirtualCamera.LookAt = focusObjectTransform;
        previousVirtualCamera.Priority = 10;
        cinemachineVirtualCamera.Priority = 15;
    }
}
