using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConfirmationDialog : MonoBehaviour
{

    private Button yesButton;
    private Button noButton;


    // Start is called before the first frame update
    void Start()
    {// search for child buttons
        Transform[] tArray = GetComponentsInChildren<Transform>();
        foreach (var t in tArray)
        {
            if (t.name == "YesButton") {
                yesButton = t.GetComponent<Button>();
            }
            else if (t.name == "NoButton") {
                noButton = t.GetComponent<Button>();
            }
        }
        // check the buttons to be found
        if (yesButton == null || noButton == null) {
            Debug.LogWarning("Could not find dialog button in ConfirmationDialog Script");
        }
        else {
            yesButton.onClick.AddListener(Confirm);
            noButton.onClick.AddListener(Reject);
        }
    }

    public void Confirm(){
        Debug.Log("Dialog confirmed");
        HideDialog();
    }
    public void Reject() {
        Debug.Log("Dialog Rejected");
        HideDialog();
    }


    public void ShowDialog() {
        gameObject.SetActive(true);
    }
    public void HideDialog() {
        gameObject.SetActive(false);
    }
}
