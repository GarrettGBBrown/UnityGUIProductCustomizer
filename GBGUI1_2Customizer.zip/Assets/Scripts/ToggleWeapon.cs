using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleWeapon : MonoBehaviour
{
    [SerializeField]
    public GameObject Item;
    [SerializeField]
    public GameObject ItemEquipped;

    [SerializeField]
    public GameObject CheckBox;

    bool Equipped = false;
    

    public void toggleObject(){
        if(!Equipped){
            Item.SetActive(false);
            ItemEquipped.SetActive(true);
            CheckBox.SetActive(true);
            Equipped = true;
        }
        else {
            Item.SetActive(true);
            ItemEquipped.SetActive(false);
            CheckBox.SetActive(false);
            Equipped = false;
        }
    }
}
