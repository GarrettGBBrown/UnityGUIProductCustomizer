using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MyGuiListeners : MonoBehaviour
{
    [SerializeField]
    Renderer cubeRenderer;
    [SerializeField]
    private GameObject myCube;
    [SerializeField]
    private Slider colorSlider;
    [SerializeField]
    private Material characterMaterial;
    
    private void start() {
        if (myCube == null) {
            myCube = GameObject.FindGameObjectWithTag("EditableCube");

            if (myCube == null) {
                Debug.LogWarning("GUI Listener is missing reference to myCube and is not set");
            }
            else {
                cubeRenderer = myCube.GetComponent<Renderer>();
            }
        }
        // try to find the colorSlider if none provided
        if (colorSlider == null) {
            colorSlider = GetComponentInChildren<Slider>();
            if (colorSlider == null) {
                Debug.LogWarning("GUI Listener is missing reference to colorSlider and is not set");
            }
        }

    }

    public void ButtonClicked() {
        Debug.Log("Button Clicked");
    }

    public void SliderRValueChanged (float newValue) {
        Renderer cubeRenderer = myCube.GetComponent<Renderer>();

        if (cubeRenderer != null) {
            Material cubeMaterial = cubeRenderer.material;

            if (cubeMaterial != null) {
                Color myColor = cubeMaterial.color;
                myColor.r = newValue /255.0f;
                cubeMaterial.color = myColor;
            }
        }
    }
    public void SliderGValueChanged (float newValue) {
        Renderer cubeRenderer = myCube.GetComponent<Renderer>();

        if (cubeRenderer != null) {
            Material cubeMaterial = cubeRenderer.material;

            if (cubeMaterial != null) {
                Color myColor = cubeMaterial.color;
                myColor.g = newValue /255.0f;
                cubeMaterial.color = myColor;
            }
        }
    }
    public void SliderBValueChanged (float newValue) {
        Renderer cubeRenderer = myCube.GetComponent<Renderer>();

        if (cubeRenderer != null) {
            Material cubeMaterial = cubeRenderer.material;

            if (cubeMaterial != null) {
                Color myColor = cubeMaterial.color;
                myColor.b = newValue /255.0f;
                cubeMaterial.color = myColor;
            }
        }
    }
    
    public void EnableSlider (bool enable) {
        if(colorSlider != null){
            //colorSlider.enabled = enable;
            colorSlider.interactable = enable;


        }

    }
    
}
