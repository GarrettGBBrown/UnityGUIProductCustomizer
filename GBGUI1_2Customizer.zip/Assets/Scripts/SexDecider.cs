using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SexDecider : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    public GameObject male;
    [SerializeField]
    public GameObject female;

    [SerializeField]
    public GameObject maleHair;
    [SerializeField]
    public GameObject femaleHair;
    //private bool isMale = true;


    public void toggleMale(){
        female.SetActive(false);
        male.SetActive(true);
        femaleHair.SetActive(false);
        maleHair.SetActive(true);
    }
    public void toggleFemale(){
        male.SetActive(false);
        female.SetActive(true);
        maleHair.SetActive(false);
        femaleHair.SetActive(true);
    }
}
