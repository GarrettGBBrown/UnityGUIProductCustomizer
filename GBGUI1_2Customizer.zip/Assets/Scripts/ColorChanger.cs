using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ColorChanger : MonoBehaviour
{
    [SerializeField]
    public Slider red;
    [SerializeField]
    public Slider blue;
    [SerializeField]
    public Slider green;
    [SerializeField]
    public Material mat;
    
   public void onEdit(){
    Color color = new Color(0.5f,0.5f,0.5f,1f);
    color.r = red.value;
    color.g = green.value;
    color.b = blue.value;
    //object1.material.color = color;
    //object1.material.SetColor("_Color",color);
    mat.color = color;
    mat.SetColor("_Color",color);

   }
}
